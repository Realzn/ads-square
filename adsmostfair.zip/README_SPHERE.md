# Sphère de Dyson — Guide d'intégration

R�seau publicitaire mutualiste à abonnements journaliers annulables.

---

## Architecture des rangs

| Rang | Tiers | Prix/jour | Tâches quotidiennes |
|---|---|---|---|
| ☀️ L'Élu | `epicenter` | €1 000 | Slot parfait |
| 🔵 L'Architecte | `prestige`, `elite` | €50–100 | Créer contenu + recommander 2 membres + offrir avantage |
| 🟡 Le Bâtisseur | `business`, `standard` | €3–10 | Partager la grille + mettre en avant un voisin |
| ⚪ Le Signal | `viral` | €1 | Partager la grille |

## Principe

Chaque membre paie pour être vu et amplifie les autres via ses tâches quotidiennes déclaratives.
Tâches non accomplies → suspension automatique (délai selon rang). Annulation possible à tout moment.

---

## Nouveaux fichiers ajoutés

```
supabase/020_sphere_dyson.sql         ← À exécuter en premier dans Supabase SQL Editor

app/sphere/page.js                    ← Dashboard cockpit (route /sphere)
app/api/stripe/subscribe/route.js     ← Checkout Stripe mode subscription journalier
app/api/stripe/webhook-subscription/  ← Webhook abonnements (activ. / paiement / annulation)
app/api/tasks/route.js                ← Tâches du jour (GET + POST compléter)
app/api/community/route.js            ← Fil communautaire (GET + POST like)
app/api/subscriptions/cancel/         ← Annulation abonnement
app/api/subscriptions/reactivate/     ← Réactivation après suspension
app/api/cron/daily-sphere/            ← Cron génération tâches + vérification suspensions
lib/emails-sphere.js                  ← Emails transactionnels Sphère
```

---

## Setup

### 1. Migration Supabase
```sql
-- Exécuter dans Supabase Dashboard → SQL Editor
-- supabase/020_sphere_dyson.sql
```

### 2. Variables d'environnement à ajouter
```env
STRIPE_WEBHOOK_SECRET_SUB=whsec_...   # Webhook séparé pour abonnements (optionnel)
CRON_SECRET=your-cron-secret          # Token pour les crons (fallback sur ADMIN_SECRET)
EMAIL_FROM=Sphère de Dyson <noreply@ads-square.com>
```

### 3. Crons à configurer
```
6h00  → GET /api/cron/daily-sphere?step=tasks&token={CRON_SECRET}
23h00 → GET /api/cron/daily-sphere?step=suspend&token={CRON_SECRET}
```

### 4. Webhook Stripe
Ajouter un endpoint dans le dashboard Stripe pointant vers :
`/api/stripe/webhook-subscription`

Événements à écouter :
- `checkout.session.completed`
- `invoice.payment_succeeded`
- `invoice.payment_failed`
- `customer.subscription.deleted`

---

## Dashboard membre
Accessible à `/sphere` — le membre voit :
- Ses tâches du jour avec formulaire déclaratif
- Son streak et sa jauge de suspension
- Le fil communautaire (amplifications de tous les membres)
- Son abonnement avec bouton d'annulation
